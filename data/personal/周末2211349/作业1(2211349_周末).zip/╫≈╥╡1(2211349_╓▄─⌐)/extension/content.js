// 从本地存储加载并展示之前的高亮和笔记
window.onload = function() {
    const key = window.location.href;
    chrome.storage.local.get([key], (result) => {
        const data = result[key];
        if (data) {
            if (data.highlights) {
                data.highlights.forEach(highlightText);
            }
            if (data.notes) {
                data.notes.forEach(addNote);
            }
        }
    });
};

// 函数：高亮文本
function highlightText(text) {
    const bodyText = document.body.innerHTML;
    const highlightedText = `<span style="background-color: yellow">${text}</span>`;
    document.body.innerHTML = bodyText.replace(text, highlightedText);
}

// 函数：添加笔记
function addNote(note) {
    const noteDiv = document.createElement('div');
    noteDiv.style.border = '1px solid #ddd';
    noteDiv.style.padding = '10px';
    noteDiv.style.marginTop = '10px';
    noteDiv.textContent = note;
    document.body.appendChild(noteDiv);
}

// 函数：清除页面上的高亮和笔记
function clearAllData() {
    // 清除所有高亮
    const highlightedElements = document.querySelectorAll('span[style*="background-color: yellow"]');
    highlightedElements.forEach(el => el.replaceWith(el.textContent));

    // 清除所有笔记
    const noteElements = document.querySelectorAll('div[style*="border: 1px solid #ddd"]');
    noteElements.forEach(el => el.remove());
}
