// 监听高亮按钮
document.getElementById('highlightText').addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            func: highlightSelectedText
        });
    });
});

// 监听保存笔记按钮
document.getElementById('saveNote').addEventListener('click', () => {
    const note = document.getElementById('noteInput').value;
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            func: addNote,
            args: [note]
        });
    });
});

// 监听清除数据按钮
document.getElementById('clearData').addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            func: clearAllData
        });
    });
});

// 定义高亮选中文本的函数
function highlightSelectedText() {
    const selection = window.getSelection().toString();
    if (selection) {
        const span = document.createElement('span');
        span.style.backgroundColor = 'yellow';
        span.textContent = selection;
        const range = window.getSelection().getRangeAt(0);
        range.deleteContents();
        range.insertNode(span);
        
        saveData('highlight', selection);
    } else {
        alert('Please select some text to highlight.');
    }
}

// 定义添加笔记的函数
function addNote(note) {
    if (note) {
        const noteDiv = document.createElement('div');
        noteDiv.style.border = '1px solid #ddd';
        noteDiv.style.padding = '10px';
        noteDiv.style.marginTop = '10px';
        noteDiv.textContent = note;
        document.body.appendChild(noteDiv);
        
        saveData('note', note);
    } else {
        alert('Please enter a note.');
    }
}

// 清除本页面所有笔记和高亮
function clearAllData() {
    const key = window.location.href;
    chrome.storage.local.remove(key, () => {
        alert('All notes and highlights have been cleared.');
        window.location.reload();  // 刷新页面以清除视觉上的高亮和笔记
    });
}

// 保存高亮和笔记到本地存储
function saveData(type, content) {
    const key = window.location.href;
    chrome.storage.local.get([key], (result) => {
        const data = result[key] || { highlights: [], notes: [] };
        if (type === 'highlight') {
            data.highlights.push(content);
        } else if (type === 'note') {
            data.notes.push(content);
        }
        chrome.storage.local.set({ [key]: data });
    });
}
