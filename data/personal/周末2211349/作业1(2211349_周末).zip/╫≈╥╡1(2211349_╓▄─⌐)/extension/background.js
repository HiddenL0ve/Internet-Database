chrome.runtime.onInstalled.addListener(() => {
    console.log("Web Page Highlighter & Note Taker installed!");
});
