document.getElementById('clearHighlights').addEventListener('click', function() {
    chrome.tabs.executeScript({
      code: 'document.querySelectorAll(".highlight").forEach(e => e.style.backgroundColor = "");'
    });
    window.close();
  });
  