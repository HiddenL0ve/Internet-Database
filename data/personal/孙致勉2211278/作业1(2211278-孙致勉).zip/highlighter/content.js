document.addEventListener('mouseup', function() {
    var selection = window.getSelection();
    if (!selection.isCollapsed) {
      var span = document.createElement('span');
      span.className = 'highlight';
      span.style.backgroundColor = 'yellow';
      span.textContent = selection.toString();
  
      var range = selection.getRangeAt(0);
      range.deleteContents();
      range.insertNode(span);
    }
  });
  